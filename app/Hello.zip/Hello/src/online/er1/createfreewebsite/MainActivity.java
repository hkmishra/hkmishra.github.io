package online.er1.createfreewebsite;

import android.graphics.Bitmap;
import android.app.Activity;
//import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;

public class MainActivity extends Activity {
    private WebView mywebView;
    String ShowOrHideWebViewInitialUse = "show";
    private ProgressBar spinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mywebView = (WebView) findViewById(R.id.webview);
        spinner = (ProgressBar)findViewById(R.id.progressBar1);
        WebSettings webSettings= mywebView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        mywebView.getSettings().setDomStorageEnabled(true);
        mywebView.setWebViewClient(new CustomWebViewClient());
        mywebView.loadUrl("http://er1.online/");

    }

    public void onBackPressed() {
        if(mywebView.canGoBack())
        {
            mywebView.goBack();
        }

        else{
            super.onBackPressed();
        }
    }


    // This allows for a splash screen
    // (and hide elements once the page loads)
    private class CustomWebViewClient extends WebViewClient {

        @Override
        public void onPageStarted(WebView webview, String url, Bitmap favicon) {

            // only make it invisible the FIRST time the app is run
         //   if (ShowOrHideWebViewInitialUse.equals("show")) {
          //      webview.setVisibility(webview.INVISIBLE);
          //  }
        }

        @Override
        public void onPageFinished(WebView view, String url) {
             findViewById(R.id.progressBar1).setVisibility(View.GONE);
           // ShowOrHideWebViewInitialUse = "hide";
           // spinner.setVisibility(View.GONE);

          //  view.setVisibility(mywebView.VISIBLE);
           // super.onPageFinished(view, url);

        }



    }


}